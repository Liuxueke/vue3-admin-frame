<template>
    <header class="theheader">
        <div class="fl logo">区域影像系统升级改造（含云影像服务）</div>
        <div class="fr pr10">
            <div class="username flex-center"><i class="mr10"><img src="@/assets/doctor_boy.png"/></i>影像中心系统管理员</div>
        </div>
    </header>
</template>
<style lang="less">
.theheader{ width:100%; height:50px; border-bottom: 1px solid #e4e7ed;background: #f7f7f7;}
.logo{ line-height:50px; font-size:18px; padding:0 10px;}
.username{
    height:50px;
    i{ display:block; width:34px;height:34px; border-radius:100%;}
    img{ display:block;width:100%;}
}
</style>