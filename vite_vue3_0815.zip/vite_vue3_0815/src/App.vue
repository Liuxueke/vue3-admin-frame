<template>
    <RouterView/>
</template>

<style>
*{ padding:0;margin:0;}
</style>