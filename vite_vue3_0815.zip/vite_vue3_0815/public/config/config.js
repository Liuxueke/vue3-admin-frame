var configUrl = {
    apiUrl: 'http://localhost:8080',
    frontEndUrl: 'http://localhost:8080',
}